# About `bevy_schedule_dispatch`

This crate turns function calls into schedule runners that operate on a globalized ECS world.

## TODO

- [ ] Explain why `App` and not `World`.
- [ ] Provide safety documentation for unsafe blocks.
- [ ] Provide usecases and non-usecases.
